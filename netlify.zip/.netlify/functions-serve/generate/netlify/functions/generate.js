var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/generate.mjs
var generate_exports = {};
__export(generate_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(generate_exports);

// src/http.mjs
var jsonHeaders = {
  "content-type": "application/json; charset=utf-8",
  "access-control-allow-origin": process.env.ALLOWED_ORIGIN || "*",
  "access-control-allow-headers": "content-type, authorization, x-admin-token",
  "access-control-allow-methods": "GET, POST, OPTIONS"
};
function optionsResponse() {
  return {
    statusCode: 204,
    headers: jsonHeaders,
    body: ""
  };
}
function json(statusCode, payload) {
  return {
    statusCode,
    headers: jsonHeaders,
    body: JSON.stringify(payload)
  };
}
function readJson(event) {
  if (!event.body)
    return {};
  try {
    return JSON.parse(event.body);
  } catch {
    const error = new Error("Body must be valid JSON");
    error.statusCode = 400;
    throw error;
  }
}
function bearerToken(event) {
  const header = event.headers.authorization || event.headers.Authorization || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : "";
}

// src/crypto.mjs
var import_node_crypto = __toESM(require("crypto"), 1);
function sha256(value) {
  return import_node_crypto.default.createHash("sha256").update(value, "utf8").digest("hex");
}

// node_modules/@netlify/runtime-utils/dist/main.js
var getString = (input) => typeof input === "string" ? input : JSON.stringify(input);
var base64Decode = globalThis.Buffer ? (input) => Buffer.from(input, "base64").toString() : (input) => atob(input);
var base64Encode = globalThis.Buffer ? (input) => Buffer.from(getString(input)).toString("base64") : (input) => btoa(getString(input));

// node_modules/@netlify/blobs/dist/chunk-YKFYEM4M.js
var getEnvironment = () => {
  const { Deno, Netlify, process: process2 } = globalThis;
  return Netlify?.env ?? Deno?.env ?? {
    delete: (key) => delete process2?.env[key],
    get: (key) => process2?.env[key],
    has: (key) => Boolean(process2?.env[key]),
    set: (key, value) => {
      if (process2?.env) {
        process2.env[key] = value;
      }
    },
    toObject: () => process2?.env ?? {}
  };
};
var getEnvironmentContext = () => {
  const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
  if (typeof context !== "string" || !context) {
    return {};
  }
  const data = base64Decode(context);
  try {
    return JSON.parse(data);
  } catch {
  }
  return {};
};
var MissingBlobsEnvironmentError = class extends Error {
  constructor(requiredProperties) {
    super(
      `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
        ", "
      )}`
    );
    this.name = "MissingBlobsEnvironmentError";
  }
};
var BASE64_PREFIX = "b64;";
var METADATA_HEADER_INTERNAL = "x-amz-meta-user";
var METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
var METADATA_MAX_SIZE = 2 * 1024;
var encodeMetadata = (metadata) => {
  if (!metadata) {
    return null;
  }
  const encodedObject = base64Encode(JSON.stringify(metadata));
  const payload = `b64;${encodedObject}`;
  if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
    throw new Error("Metadata object exceeds the maximum size");
  }
  return payload;
};
var decodeMetadata = (header) => {
  if (!header?.startsWith(BASE64_PREFIX)) {
    return {};
  }
  const encodedData = header.slice(BASE64_PREFIX.length);
  const decodedData = base64Decode(encodedData);
  const metadata = JSON.parse(decodedData);
  return metadata;
};
var getMetadataFromResponse = (response) => {
  if (!response.headers) {
    return {};
  }
  const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
  try {
    return decodeMetadata(value);
  } catch {
    throw new Error(
      "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
    );
  }
};
var NF_ERROR = "x-nf-error";
var NF_REQUEST_ID = "x-nf-request-id";
var BlobsInternalError = class extends Error {
  constructor(res) {
    let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
    if (res.headers.has(NF_REQUEST_ID)) {
      details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
    }
    super(`Netlify Blobs has generated an internal error (${details})`);
    this.name = "BlobsInternalError";
  }
};
var collectIterator = async (iterator) => {
  const result = [];
  for await (const item of iterator) {
    result.push(item);
  }
  return result;
};
var BlobsConsistencyError = class extends Error {
  constructor() {
    super(
      `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
    );
    this.name = "BlobsConsistencyError";
  }
};
var regions = {
  "us-east-1": true,
  "us-east-2": true,
  "eu-central-1": true,
  "ap-southeast-1": true,
  "ap-southeast-2": true
};
var isValidRegion = (input) => Object.keys(regions).includes(input);
var InvalidBlobsRegionError = class extends Error {
  constructor(region) {
    super(
      `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
    );
    this.name = "InvalidBlobsRegionError";
  }
};
var DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
var MIN_RETRY_DELAY = 1e3;
var MAX_RETRY = 5;
var RATE_LIMIT_HEADER = "X-RateLimit-Reset";
var fetchAndRetry = async (fetch2, url, options, attemptsLeft = MAX_RETRY) => {
  try {
    const res = await fetch2(url, options);
    if (attemptsLeft > 0 && (res.status === 429 || res.status >= 500)) {
      const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
      await sleep(delay);
      return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
    }
    return res;
  } catch (error) {
    if (attemptsLeft === 0) {
      throw error;
    }
    const delay = getDelay();
    await sleep(delay);
    return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
  }
};
var getDelay = (rateLimitReset) => {
  if (!rateLimitReset) {
    return DEFAULT_RETRY_DELAY;
  }
  return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
};
var sleep = (ms) => new Promise((resolve) => {
  setTimeout(resolve, ms);
});
var SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
var Client = class {
  constructor({ apiURL, consistency, edgeURL, fetch: fetch2, region, siteID, token, uncachedEdgeURL }) {
    this.apiURL = apiURL;
    this.consistency = consistency ?? "eventual";
    this.edgeURL = edgeURL;
    this.fetch = fetch2 ?? globalThis.fetch;
    this.region = region;
    this.siteID = siteID;
    this.token = token;
    this.uncachedEdgeURL = uncachedEdgeURL;
    if (!this.fetch) {
      throw new Error(
        "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
      );
    }
  }
  async getFinalRequest({
    consistency: opConsistency,
    key,
    metadata,
    method,
    parameters = {},
    storeName
  }) {
    const encodedMetadata = encodeMetadata(metadata);
    const consistency = opConsistency ?? this.consistency;
    let urlPath = `/${this.siteID}`;
    if (storeName) {
      urlPath += `/${storeName}`;
    }
    if (key) {
      urlPath += `/${key}`;
    }
    if (this.edgeURL) {
      if (consistency === "strong" && !this.uncachedEdgeURL) {
        throw new BlobsConsistencyError();
      }
      const headers = {
        authorization: `Bearer ${this.token}`
      };
      if (encodedMetadata) {
        headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
      }
      if (this.region) {
        urlPath = `/region:${this.region}${urlPath}`;
      }
      const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
      for (const key2 in parameters) {
        url2.searchParams.set(key2, parameters[key2]);
      }
      return {
        headers,
        url: url2.toString()
      };
    }
    const apiHeaders = { authorization: `Bearer ${this.token}` };
    const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
    for (const key2 in parameters) {
      url.searchParams.set(key2, parameters[key2]);
    }
    if (this.region) {
      url.searchParams.set("region", this.region);
    }
    if (storeName === void 0 || key === void 0) {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    if (encodedMetadata) {
      apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
    }
    if (method === "head" || method === "delete") {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    const res = await this.fetch(url.toString(), {
      headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
      method
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
    const { url: signedURL } = await res.json();
    const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
    return {
      headers: userHeaders,
      url: signedURL
    };
  }
  async makeRequest({
    body,
    consistency,
    headers: extraHeaders,
    key,
    metadata,
    method,
    parameters,
    storeName
  }) {
    const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
      consistency,
      key,
      metadata,
      method,
      parameters,
      storeName
    });
    const headers = {
      ...baseHeaders,
      ...extraHeaders
    };
    if (method === "put") {
      headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
    }
    const options = {
      body,
      headers,
      method
    };
    if (body instanceof ReadableStream) {
      options.duplex = "half";
    }
    return fetchAndRetry(this.fetch, url, options);
  }
};
var getClientOptions = (options, contextOverride) => {
  const context = contextOverride ?? getEnvironmentContext();
  const siteID = context.siteID ?? options.siteID;
  const token = context.token ?? options.token;
  if (!siteID || !token) {
    throw new MissingBlobsEnvironmentError(["siteID", "token"]);
  }
  if (options.region !== void 0 && !isValidRegion(options.region)) {
    throw new InvalidBlobsRegionError(options.region);
  }
  const clientOptions = {
    apiURL: context.apiURL ?? options.apiURL,
    consistency: options.consistency,
    edgeURL: context.edgeURL ?? options.edgeURL,
    fetch: options.fetch,
    region: options.region,
    siteID,
    token,
    uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
  };
  return clientOptions;
};

// node_modules/@netlify/blobs/dist/main.js
var DEPLOY_STORE_PREFIX = "deploy:";
var LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
var SITE_STORE_PREFIX = "site:";
var Store = class _Store {
  constructor(options) {
    this.client = options.client;
    if ("deployID" in options) {
      _Store.validateDeployID(options.deployID);
      let name = DEPLOY_STORE_PREFIX + options.deployID;
      if (options.name) {
        name += `:${options.name}`;
      }
      this.name = name;
    } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
      const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
      _Store.validateStoreName(storeName);
      this.name = storeName;
    } else {
      _Store.validateStoreName(options.name);
      this.name = SITE_STORE_PREFIX + options.name;
    }
  }
  async delete(key) {
    const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
    if (![200, 204, 404].includes(res.status)) {
      throw new BlobsInternalError(res);
    }
  }
  async get(key, options) {
    const { consistency, type } = options ?? {};
    const res = await this.client.makeRequest({ consistency, key, method: "get", storeName: this.name });
    if (res.status === 404) {
      return null;
    }
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
    if (type === void 0 || type === "text") {
      return res.text();
    }
    if (type === "arrayBuffer") {
      return res.arrayBuffer();
    }
    if (type === "blob") {
      return res.blob();
    }
    if (type === "json") {
      return res.json();
    }
    if (type === "stream") {
      return res.body;
    }
    throw new BlobsInternalError(res);
  }
  async getMetadata(key, { consistency } = {}) {
    const res = await this.client.makeRequest({ consistency, key, method: "head", storeName: this.name });
    if (res.status === 404) {
      return null;
    }
    if (res.status !== 200 && res.status !== 304) {
      throw new BlobsInternalError(res);
    }
    const etag = res?.headers.get("etag") ?? void 0;
    const metadata = getMetadataFromResponse(res);
    const result = {
      etag,
      metadata
    };
    return result;
  }
  async getWithMetadata(key, options) {
    const { consistency, etag: requestETag, type } = options ?? {};
    const headers = requestETag ? { "if-none-match": requestETag } : void 0;
    const res = await this.client.makeRequest({
      consistency,
      headers,
      key,
      method: "get",
      storeName: this.name
    });
    if (res.status === 404) {
      return null;
    }
    if (res.status !== 200 && res.status !== 304) {
      throw new BlobsInternalError(res);
    }
    const responseETag = res?.headers.get("etag") ?? void 0;
    const metadata = getMetadataFromResponse(res);
    const result = {
      etag: responseETag,
      metadata
    };
    if (res.status === 304 && requestETag) {
      return { data: null, ...result };
    }
    if (type === void 0 || type === "text") {
      return { data: await res.text(), ...result };
    }
    if (type === "arrayBuffer") {
      return { data: await res.arrayBuffer(), ...result };
    }
    if (type === "blob") {
      return { data: await res.blob(), ...result };
    }
    if (type === "json") {
      return { data: await res.json(), ...result };
    }
    if (type === "stream") {
      return { data: res.body, ...result };
    }
    throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
  }
  list(options = {}) {
    const iterator = this.getListIterator(options);
    if (options.paginate) {
      return iterator;
    }
    return collectIterator(iterator).then(
      (items) => items.reduce(
        (acc, item) => ({
          blobs: [...acc.blobs, ...item.blobs],
          directories: [...acc.directories, ...item.directories]
        }),
        { blobs: [], directories: [] }
      )
    );
  }
  async set(key, data, { metadata } = {}) {
    _Store.validateKey(key);
    const res = await this.client.makeRequest({
      body: data,
      key,
      metadata,
      method: "put",
      storeName: this.name
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
  }
  async setJSON(key, data, { metadata } = {}) {
    _Store.validateKey(key);
    const payload = JSON.stringify(data);
    const headers = {
      "content-type": "application/json"
    };
    const res = await this.client.makeRequest({
      body: payload,
      headers,
      key,
      metadata,
      method: "put",
      storeName: this.name
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
  }
  static formatListResultBlob(result) {
    if (!result.key) {
      return null;
    }
    return {
      etag: result.etag,
      key: result.key
    };
  }
  static validateKey(key) {
    if (key === "") {
      throw new Error("Blob key must not be empty.");
    }
    if (key.startsWith("/") || key.startsWith("%2F")) {
      throw new Error("Blob key must not start with forward slash (/).");
    }
    if (new TextEncoder().encode(key).length > 600) {
      throw new Error(
        "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
      );
    }
  }
  static validateDeployID(deployID) {
    if (!/^\w{1,24}$/.test(deployID)) {
      throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
    }
  }
  static validateStoreName(name) {
    if (name.includes("/") || name.includes("%2F")) {
      throw new Error("Store name must not contain forward slashes (/).");
    }
    if (new TextEncoder().encode(name).length > 64) {
      throw new Error(
        "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
      );
    }
  }
  getListIterator(options) {
    const { client, name: storeName } = this;
    const parameters = {};
    if (options?.prefix) {
      parameters.prefix = options.prefix;
    }
    if (options?.directories) {
      parameters.directories = "true";
    }
    return {
      [Symbol.asyncIterator]() {
        let currentCursor = null;
        let done = false;
        return {
          async next() {
            if (done) {
              return { done: true, value: void 0 };
            }
            const nextParameters = { ...parameters };
            if (currentCursor !== null) {
              nextParameters.cursor = currentCursor;
            }
            const res = await client.makeRequest({
              method: "get",
              parameters: nextParameters,
              storeName
            });
            let blobs = [];
            let directories = [];
            if (![200, 204, 404].includes(res.status)) {
              throw new BlobsInternalError(res);
            }
            if (res.status === 404) {
              done = true;
            } else {
              const page = await res.json();
              if (page.next_cursor) {
                currentCursor = page.next_cursor;
              } else {
                done = true;
              }
              blobs = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
              directories = page.directories ?? [];
            }
            return {
              done: false,
              value: {
                blobs,
                directories
              }
            };
          }
        };
      }
    };
  }
};
var getStore = (input) => {
  if (typeof input === "string") {
    const clientOptions = getClientOptions({});
    const client = new Client(clientOptions);
    return new Store({ client, name: input });
  }
  if (typeof input?.name === "string" && typeof input?.siteID === "string" && typeof input?.token === "string") {
    const { name, siteID, token } = input;
    const clientOptions = getClientOptions(input, { siteID, token });
    if (!name || !siteID || !token) {
      throw new MissingBlobsEnvironmentError(["name", "siteID", "token"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.name === "string") {
    const { name } = input;
    const clientOptions = getClientOptions(input);
    if (!name) {
      throw new MissingBlobsEnvironmentError(["name"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.deployID === "string") {
    const clientOptions = getClientOptions(input);
    const { deployID } = input;
    if (!deployID) {
      throw new MissingBlobsEnvironmentError(["deployID"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, deployID });
  }
  throw new Error(
    "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
  );
};

// src/store.mjs
var import_promises = require("fs/promises");
var import_node_path = __toESM(require("path"), 1);
var STORE_NAME = "easy-keyword-ai-proxy";
var CONFIG_KEY = "config";
var LOCAL_DATA_DIR = import_node_path.default.join(process.cwd(), ".data");
var LOCAL_CONFIG_PATH = import_node_path.default.join(LOCAL_DATA_DIR, "config.json");
var defaultConfig = {
  version: 1,
  updatedAt: null,
  providerOrder: ["groq", "gemini"],
  groq: {
    model: "meta-llama/llama-4-scout-17b-16e-instruct",
    keys: [],
    cursor: 0
  },
  gemini: {
    model: "gemini-2.5-flash",
    keys: [],
    cursor: 0
  },
  extensionKeys: []
};
function configStore() {
  return getStore(STORE_NAME);
}
function shouldUseLocalStore() {
  return process.env.LOCAL_FILE_STORE === "1" || !process.env.NETLIFY && !process.env.NETLIFY_BLOBS_CONTEXT;
}
async function readLocalConfig() {
  try {
    const raw = await (0, import_promises.readFile)(LOCAL_CONFIG_PATH, "utf8");
    return JSON.parse(raw);
  } catch {
    return null;
  }
}
async function writeLocalConfig(config) {
  await (0, import_promises.mkdir)(LOCAL_DATA_DIR, { recursive: true });
  await (0, import_promises.writeFile)(LOCAL_CONFIG_PATH, JSON.stringify(config, null, 2), "utf8");
}
async function loadConfig() {
  let config;
  if (shouldUseLocalStore()) {
    config = await readLocalConfig();
  } else {
    const store = configStore();
    config = await store.get(CONFIG_KEY, { type: "json", consistency: "strong" });
  }
  return {
    ...defaultConfig,
    ...config || {},
    groq: { ...defaultConfig.groq, ...config?.groq || {} },
    gemini: { ...defaultConfig.gemini, ...config?.gemini || {} },
    extensionKeys: config?.extensionKeys || []
  };
}
async function saveConfig(config) {
  const next = {
    ...config,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (shouldUseLocalStore()) {
    await writeLocalConfig(next);
  } else {
    const store = configStore();
    await store.setJSON(CONFIG_KEY, next);
  }
  return next;
}

// src/auth.mjs
async function validateExtensionToken(token) {
  if (!token)
    return null;
  const config = await loadConfig();
  const tokenHash = sha256(token);
  const key = config.extensionKeys.find((item) => item.hash === tokenHash && item.active !== false);
  return key || null;
}

// src/prompt.mjs
var adobeCategories = [
  "animals",
  "buildings and architecture",
  "business",
  "drinks",
  "the environment",
  "states of mind",
  "food",
  "graphic resources",
  "hobbies and leisure",
  "industry",
  "landscapes",
  "lifestyle",
  "people",
  "plants and flowers",
  "culture and religion",
  "science",
  "social issues",
  "sports",
  "technology",
  "transport",
  "travel"
];
function buildMetadataPrompt(settings = {}, context = {}) {
  const keywordCount = Number(settings.keywordCount || settings.maxKeywordsNum || 49);
  const singleWord = Boolean(settings.singleWordKeywords || settings.isSingleKeywords);
  const niche = Boolean(settings.nicheKeywords || settings.isNicheKeywords);
  const existingTitle = context.existingTitle || "";
  const existingKeywords = Array.isArray(context.existingKeywords) ? context.existingKeywords.join(", ") : "";
  return [
    "You generate Adobe Stock metadata from an image.",
    "Return only valid compact JSON. Do not include markdown fences or explanations.",
    "",
    "Rules:",
    "- title must be natural English and under 200 characters.",
    `- keywords must be unique, relevant, and no more than ${keywordCount}.`,
    singleWord ? "- every keyword must be a single word." : "- multi-word keywords are allowed only when natural for stock metadata.",
    niche ? "- include more niche/specific terms while keeping relevance." : "- prefer broadly searchable stock keywords first.",
    "- category must be exactly one allowed category.",
    "- peopleOrProperty must be true if recognizable people, property, buildings, vehicles, brands, or private locations appear.",
    "- fileTypeFlag must be true only when the image is likely vector/illustration/graphic resource instead of a regular photo.",
    "",
    `Allowed categories: ${adobeCategories.join(" | ")}`,
    "",
    existingTitle ? `Existing title hint: ${existingTitle}` : "",
    existingKeywords ? `Existing keyword hints: ${existingKeywords}` : "",
    "",
    "Schema:",
    '{"title":"string","keywords":["string"],"category":"business","peopleOrProperty":false,"fileTypeFlag":false}'
  ].filter(Boolean).join("\n");
}

// src/normalize.mjs
function stripCodeFence(text) {
  return String(text || "").replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
}
function extractJson(text) {
  const cleaned = stripCodeFence(text);
  try {
    return JSON.parse(cleaned);
  } catch {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start)
      return JSON.parse(cleaned.slice(start, end + 1));
    throw new Error("Provider returned invalid JSON");
  }
}
function normalizeCategory(value) {
  const lower = String(value || "").toLowerCase().trim();
  return adobeCategories.includes(lower) ? lower : "business";
}
function normalizeKeywords(value, maxKeywords = 49) {
  const raw = Array.isArray(value) ? value : String(value || "").split(",");
  const seen = /* @__PURE__ */ new Set();
  const result = [];
  for (const item of raw) {
    const keyword = String(item).toLowerCase().replace(/\s+/g, " ").trim();
    if (!keyword || seen.has(keyword))
      continue;
    seen.add(keyword);
    result.push(keyword);
    if (result.length >= maxKeywords)
      break;
  }
  return result;
}
function normalizeMetadata(providerText, settings = {}) {
  const data = typeof providerText === "string" ? extractJson(providerText) : providerText;
  const maxKeywords = Number(settings.keywordCount || settings.maxKeywordsNum || 49);
  const title = String(data.title || "").replace(/\s+/g, " ").trim().slice(0, 200);
  const keywords = normalizeKeywords(data.keywords, maxKeywords);
  const category = normalizeCategory(data.category);
  const peopleOrProperty = Boolean(data.peopleOrProperty);
  const fileTypeFlag = Boolean(data.fileTypeFlag);
  if (!title)
    throw new Error("Generated title is empty");
  if (keywords.length === 0)
    throw new Error("Generated keywords are empty");
  const legacyResult = `${title}&&${keywords.join(", ")}&&${category}&&${peopleOrProperty}&&${fileTypeFlag}`;
  return {
    title,
    keywords,
    category,
    peopleOrProperty,
    fileTypeFlag,
    legacyResult
  };
}

// src/providers.mjs
function assertImage(image) {
  if (!image?.base64 || !image?.mime)
    throw new Error("Request image.base64 and image.mime are required");
}
async function callGroq({ key, model, image, context, settings }) {
  assertImage(image);
  const prompt = buildMetadataPrompt(settings, context);
  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      authorization: `Bearer ${key}`,
      "content-type": "application/json"
    },
    body: JSON.stringify({
      model,
      temperature: 0.2,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: prompt },
            {
              type: "image_url",
              image_url: {
                url: `data:${image.mime};base64,${image.base64}`
              }
            }
          ]
        }
      ]
    })
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = payload?.error?.message || `Groq request failed with ${response.status}`;
    const error = new Error(message);
    error.statusCode = response.status;
    throw error;
  }
  const text = payload?.choices?.[0]?.message?.content || "";
  return {
    result: normalizeMetadata(text, settings),
    usage: payload?.usage || null
  };
}
async function callGemini({ key, model, image, context, settings }) {
  assertImage(image);
  const prompt = buildMetadataPrompt(settings, context);
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json"
    },
    body: JSON.stringify({
      generationConfig: {
        temperature: 0.2,
        responseMimeType: "application/json"
      },
      contents: [
        {
          role: "user",
          parts: [
            { text: prompt },
            {
              inlineData: {
                mimeType: image.mime,
                data: image.base64
              }
            }
          ]
        }
      ]
    })
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = payload?.error?.message || `Gemini request failed with ${response.status}`;
    const error = new Error(message);
    error.statusCode = response.status;
    throw error;
  }
  const text = payload?.candidates?.[0]?.content?.parts?.map((part) => part.text || "").join("") || "";
  return {
    result: normalizeMetadata(text, settings),
    usage: payload?.usageMetadata || null
  };
}

// src/rotation.mjs
var callers = {
  groq: callGroq,
  gemini: callGemini
};
function nextKey(providerConfig) {
  const keys = providerConfig.keys || [];
  if (keys.length === 0)
    return null;
  const cursor = Number(providerConfig.cursor || 0);
  const index = cursor % keys.length;
  return {
    key: keys[index],
    nextCursor: (index + 1) % keys.length
  };
}
function isRetryable(error) {
  const status = Number(error.statusCode || 0);
  return status === 0 || status === 408 || status === 409 || status === 429 || status >= 500 || status === 401 || status === 403;
}
async function generateWithRotation(config, request) {
  const providers = Array.isArray(config.providerOrder) && config.providerOrder.length > 0 ? config.providerOrder : ["groq", "gemini"];
  const errors = [];
  const nextConfig = structuredClone(config);
  for (const provider of providers) {
    const providerConfig = nextConfig[provider];
    const caller = callers[provider];
    if (!providerConfig || !caller || !providerConfig.keys?.length)
      continue;
    const attempts = providerConfig.keys.length;
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      const selected = nextKey(providerConfig);
      if (!selected)
        break;
      providerConfig.cursor = selected.nextCursor;
      try {
        const output = await caller({
          key: selected.key,
          model: providerConfig.model,
          image: request.image,
          context: request.context || {},
          settings: request.settings || {}
        });
        await saveConfig(nextConfig);
        return {
          provider,
          model: providerConfig.model,
          ...output
        };
      } catch (error2) {
        errors.push({
          provider,
          model: providerConfig.model,
          message: error2.message,
          statusCode: error2.statusCode || null
        });
        if (!isRetryable(error2))
          break;
      }
    }
  }
  await saveConfig(nextConfig);
  const error = new Error("No provider key succeeded");
  error.statusCode = 502;
  error.details = errors;
  throw error;
}

// netlify/functions/generate.mjs
var MAX_BASE64_LENGTH = Number(process.env.MAX_BASE64_LENGTH || 6e6);
function validateRequest(body) {
  if (!body || typeof body !== "object")
    throw new Error("JSON body is required");
  if (!body.image?.base64 || !body.image?.mime)
    throw new Error("image.base64 and image.mime are required");
  if (!/^image\/(png|jpe?g|webp)$/i.test(body.image.mime))
    throw new Error("Only png, jpeg, and webp images are supported");
  if (body.image.base64.length > MAX_BASE64_LENGTH)
    throw new Error("Image payload is too large");
}
async function handler(event) {
  if (event.httpMethod === "OPTIONS")
    return optionsResponse();
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, error: { code: "METHOD_NOT_ALLOWED", message: "Use POST" } });
  }
  try {
    const token = bearerToken(event);
    const extensionKey = await validateExtensionToken(token);
    if (!extensionKey) {
      return json(401, { ok: false, error: { code: "UNAUTHORIZED", message: "Invalid extension API key" } });
    }
    const body = readJson(event);
    validateRequest(body);
    const config = await loadConfig();
    const output = await generateWithRotation(config, body);
    const latestConfig = await loadConfig();
    const tokenHash = sha256(token);
    const key = latestConfig.extensionKeys.find((item) => item.hash === tokenHash);
    if (key) {
      key.lastUsedAt = (/* @__PURE__ */ new Date()).toISOString();
      await saveConfig(latestConfig);
    }
    return json(200, {
      ok: true,
      provider: output.provider,
      model: output.model,
      result: {
        title: output.result.title,
        keywords: output.result.keywords,
        category: output.result.category,
        peopleOrProperty: output.result.peopleOrProperty,
        fileTypeFlag: output.result.fileTypeFlag
      },
      legacyResult: output.result.legacyResult,
      usage: output.usage
    });
  } catch (error) {
    return json(error.statusCode || 500, {
      ok: false,
      error: {
        code: error.statusCode === 502 ? "NO_PROVIDER_AVAILABLE" : "GENERATE_ERROR",
        message: error.message,
        details: error.details || void 0
      }
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=generate.js.map
